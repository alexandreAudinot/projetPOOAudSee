﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjetPOO
{
    public class Mountain : Tile
    {
        public Mountain(): base(){ }
    }

    public class Plain : Tile
    {
        public Plain() : base() { }
    }

    public class Forest : Tile
    {
        public Forest() : base() { }
    }

    public class Desert : Tile
    {
        public Desert() : base() { }
    }
}
